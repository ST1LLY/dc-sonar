#!/bin/bash
sudo apt install software-properties-common -y
sudo add-apt-repository ppa:deadsnakes/ppa
sudo apt-get install python3.10 \
    python3.10-dev \
    libpq-dev \
    libsasl2-dev \
    libldap2-dev \
    libssl-dev \
    python3.10-venv \
    gcc \
    nginx \
    uwsgi \
    uwsgi-plugin-python3 \
    hashcat -y